// Copyright Csaba Molnar, Daniel Butum. All Rights Reserved.
#include "DlgDialogueThumbnailRenderer.h"

#include "CanvasTypes.h"

//////////////////////////////////////////////////////////////////////////
// UPaperTileSetThumbnailRenderer

UDlgDialogueThumbnailRenderer::UDlgDialogueThumbnailRenderer(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}
